for n =1:10

foto=imread('dexter.jpg');
fotog = rgb2gray ( foto );
fotodouble = im2double ( fotog );
imagen=[]
for i =1:400
  for j =1:400 
    fotomodificada(i,j) = fotodouble(i,j)+(2/(3))^n;
  end

end
imshow(fotomodificada)

imwrite(fotomodificada,n+".jpg")
end
foto1000 = fotodouble+(2/3)^1000;
foto1000s =imshow(foto1000)
imwrite(foto1000,1000+".jpg")
pause(1)
limit = 0.05;
while 1
C005 = fotodouble + (1-(n+1)/n);
 Norma = norm ( fotodouble -C005 , 2);
 if Norma > limit
 break
 end
end
formatSpec = '%.2f';
disp(['Norma=' num2str(Norma,formatSpec)])